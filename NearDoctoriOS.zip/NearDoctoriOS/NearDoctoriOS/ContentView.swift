//
//  ContentView.swift
//  NearDoctoriOS
//
//  Created by MacOsX on 5/8/24.
//

import SwiftUI
import UIKit
/*
struct ContentView: View {
    var body: some View {
        
            
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
*/

struct ContentView: View {
    var body: some View {
        LogIn()
        //Menu()
        //ListaDoctor()
        //HomeView()
    }//body
}//struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
